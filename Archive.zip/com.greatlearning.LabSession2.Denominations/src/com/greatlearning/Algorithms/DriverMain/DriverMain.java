package com.greatlearning.Algorithms.DriverMain;

import java.util.Scanner;

public class DriverMain {
public static void main(String arg[])
	{


		System.out.println("Enter  the size of currency denominations value ");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int array[]=new int[size];
		System.out.println("Enter the currency denomination values");

		for(int i=0;i<array.length;i++)
		{
			array[i]=sc.nextInt();


		}
		DenominationSort d1=new DenominationSort();
		d1.mergeSort(array,0,array.length-1);

		/*for(int i=0;i<array.length;i++)
		{ to print the sorted array 
			System.out.println(array[i]);
		}*/
		System.out.println("enter the amount to you want to pay");
		int amount=sc.nextInt();
		for(int i=0;i<array.length;i++)
		{
			if(amount>=array[i]) 
			{
				int noOfNotes=amount/array[i];
				System.out.println(array[i]+" : "+noOfNotes);
				amount=amount%array[i];


			}

		}
		if(amount>0)
		{
			System.out.println("don't have change for the "+amount);
		}

		sc.close();


	}
}


