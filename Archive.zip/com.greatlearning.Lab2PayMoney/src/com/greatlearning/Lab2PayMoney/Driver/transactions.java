package com.greatlearning.Lab2PayMoney.Driver;

import java.util.Scanner;

public class transactions {

	public static void main(String str[])
	{

		int sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of transaction array");
		int size=sc.nextInt();
		System.out.println("Enter the values of array");
		int valuesOfArray[]=new int[size];
		for(int i=0;i<valuesOfArray.length;i++)
		{
			valuesOfArray[i]=sc.nextInt();
		}

		System.out.println("Enter the total no.of targets that needs to be achieved");
		int noOfTargets=sc.nextInt();


		for(int i=1;i<=noOfTargets;i++)
		{
			System.out.println("Enter the value of target");
			int target=sc.nextInt();
			sum=0;
			for(int j=0;j<size;j++)
			{
				sum=sum+valuesOfArray[j];
				if(sum>=target)
				{
					System.out.println("Target achieved after "+(j+1)+"  transactions");
					break;
				}
			}


			if(sum<target)
				System.out.println("Target not achieved");

		}


		sc.close();
	}



}
